package com.gamingroom;

import java.util.ArrayList;
import java.util.List;
import java.util.Iterator;

/**
 * A singleton service for the game engine
 * 
 * @author coce@snhu.edu
 */

/**
 * TERM - Singleton - a class which allows only a single instance of itself to be created and gives access to created instance.
 * A singleton was created to prevent a multiplicative instantiation. 
 * This allows only one instance of GameService to be created per gameId request. 
 * To do this, the vars were given private vs public, where manipulation can be only made
 * within the local class. This prevents potential, or accidental, alterations if called. 
 */
public class GameService {

	/**
	 * A list of the active games
	 */
	private static List<Game> games = new ArrayList<Game>();

	/*
	 * Holds the next game identifier
	 */
	private static long nextGameId = 1;
	
	private static long nextPlayerId = 1;
	
	private static long nextTeamId = 1;
	
	
	private static GameService service = null;
    
    //private constructor for singleton
    private GameService(){
    }
    
    //getter for singleton
    public static GameService getInst(){
    	if(service == null) {
    		service = new GameService();
    	}
        return service;
    }

	/**
	 * Construct a new game instance
	 * 
	 * @param name the unique name of the game
	 * @return the game instance (new or existing)
	 */
	public Game addGame(String name) {

		// a local game instance
		Game game = null;
		
		/**
		 * TERM - Iterator - object used to loop through a collection, such as an array.  
		 * This iterator is looping through the games array to check for existing currentGame
		 * with requested name. If it exists, a name is returned. If it does not exist, it is
		 * created below in if (game == null) below the iterator.
		 */
		//if Game with name exists, return the existing inst without manipulating game data. 
		Iterator<Game> gameIterator = games.iterator();

		while (gameIterator.hasNext()) {
			game = gameIterator.next();
			if(game.getName().equals(name)) {
				break;
			}
		}
			
			
		if (game == null) {
			game = new Game(nextGameId++, name);
			games.add(game);
		}
			
		// return the new/existing game instance to the caller
		return game;
	}

	/**
	 * Returns the game instance at the specified index.
	 * <p>
	 * Scope is package/local for testing purposes.
	 * </p>
	 * @param index index position in the list to return
	 * @return requested game instance
	 */
	Game getGame(int index) {
		return games.get(index);
	}
	
	/**
	 * Returns the game instance with the specified id.
	 * 
	 * @param id unique identifier of game to search for
	 * @return requested game instance
	 */
	public Game getGame(long id) {

		// a local game instance
		Game game = null;

		/**
		 * Similar to the above iterator, this is iterating through the games array
		 * to check for a matching ID. If it exists, the game var is changed from 
		 * null type to the matching ID and returned. 
		 */
		
		Iterator<Game> gameIterator = games.iterator();
		
		// check list of games; if game w/ID exists, return that game
		while(gameIterator.hasNext()) {
			game = gameIterator.next();
			if(game.getId() == id) {
				return game;
			}
		}
		
		// if not found, return type null
		return null;
	}

	/**
	 * Returns the game instance with the specified name.
	 * 
	 * @param name unique name of game to search for
	 * @return requested game instance
	 */
	public Game getGame(String name) {

		// a local game instance
		Game game = null;

		/**Similar to the above iterator, this is iterating through the games array
		 * to check for a matching name. If it exists, the game var is changed from 
		 * null type to the matching name and returned.
		 */
		//  check list of games; if game w/name exists, return that game
		for (Game existingGame : games) {
			if (existingGame.getName().equals(name)){
				return existingGame;
			}
		}

		return game;
	}


	// returns and increments next player id
	public long getNextPlayerId(){
		return nextPlayerId++;
	}

	// returns and increments next team id
	public long getNextTeamId(){
		return nextTeamId++;
	}

	/**
	 * Returns the number of games currently active
	 * 
	 * @return the number of games currently active
	 */
	public int getGameCount() {
		return games.size();
	}
}