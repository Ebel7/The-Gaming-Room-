package com.gamingroom;

/*
 * Changes to Entity - removed default empty constructor in place of Entity(long id, String name)
 */


//parent class 
public class Entity{
    
    //vars
    protected long id;
    protected String name;
    
    public Entity() {
    }

    //Constructor with id and name as parameters
    public Entity(long id, String name){
    	this();
        this.id = id;
        this.name = name;
    }
    
    //getter for id
    public long getId(){
        return id;
    }
    
    //getter for name
    public String getName(){
        return name;
    }
    
    public String toString(){
        return "Entity [id=" + id + ", name=" + name + "]";
    }
}