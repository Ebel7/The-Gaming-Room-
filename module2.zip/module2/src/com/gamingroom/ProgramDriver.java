package com.gamingroom;

/**
 * Application start-up program
 * 
 * @author coce@snhu.edu
 */
public class ProgramDriver {
	
	/**
	 * The one-and-only main() method
	 * 
	 * @param args command line arguments
	 */
	public static void main(String[] args) {
		
		// get ref to instance of singleton GameService
		GameService service = GameService.getInst();
		
		System.out.println("\nAbout to test initializing game data...");
		
		// initialize with some game data
		Game game0 = service.addGame("Game #1");
		System.out.println(game0);
		
		Game game1 = service.addGame("Game #2");
		System.out.println(game1);
		
		Team team1 = new Team(0, "Team #1");
		System.out.println(team1);
		
		Team team2 = new Team(1, "Team #2");
		System.out.println(team2);
		
		Player player1 = new Player(0, "Player #1");
		System.out.println(player1);
		
		Player player2 = new Player(1, "Player #2");
		System.out.println(player2);
		
		// use another class to prove there is only one instance
		SingletonTester tester = new SingletonTester();
		tester.testSingleton();
	}
}

